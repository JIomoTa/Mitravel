export { Swiper, SwiperSlide } from './swiper-svelte.js';
